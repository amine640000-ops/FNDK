import { BadRequestException, Injectable } from "@nestjs/common";
import { dbQuery, getOne, publishEvent, withTransaction } from "@nevo/shared-infra";
import type { AiTradingActivation, AssetType, ProfitDistributionEvent, VipTier } from "@nevo/shared-types";
import { calculateDailyProfit, getTierConfig } from "@nevo/shared-utils";
import type { PoolClient } from "pg";

type DistributionCandidate = {
  user_id: string;
  tier_id: number;
  daily_roi_min: number;
  daily_roi_max: number;
  active_investment: number;
};

type ActivationTierRow = {
  id: number;
  name: string;
  min_deposit: number;
  daily_roi_min: number;
  daily_roi_max: number;
  activation_limit_per_day: number;
  activation_duration_minutes: number;
  activation_assets: AssetType[];
  active_investment: number;
};

type ActivationRow = {
  id: string;
  tier_id: number;
  tier_name: string;
  asset: AssetType;
  strategy: string;
  market_summary: string;
  thesis: string;
  status: "running" | "completed" | "expired" | "failed";
  duration_minutes: number;
  daily_slot_number: number;
  started_at: string;
  ends_at: string;
  completed_at: string | null;
  reservation_amount: number;
  entry_price: number | null;
  exit_price: number | null;
  profit: number | null;
  daily_limit: number;
};

type ReservationRulesRow = {
  reservation_failures_per_day: number;
  failed_reservations_today: number;
};

@Injectable()
export class TaskService {
  async getStatus() {
    const settings = await getOne<{ value: boolean }>(
      `
        SELECT (value #>> '{}')::boolean AS value
        FROM admin_settings
        WHERE key = 'platform.autoProfitDistribution'
      `
    );

    return {
      autoProfitDistribution: settings?.value ?? true,
      manualActivationEnabled: true,
      nextRunAt: "2026-03-18T00:05:00.000Z",
      strategyUniverse: ["Crypto Momentum", "Forex Mean Reversion", "US Index Rotation"]
    };
  }

  async getManualActivationState(userId: string) {
    await this.finalizeDueActivations(userId);

    const tier = await this.getTierForUser(userId);
    const activationCount = await getOne<{ count: number }>(
      `
        SELECT COUNT(*)::int AS count
        FROM ai_trading_activations
        WHERE user_id = $1
          AND started_at::date = CURRENT_DATE
      `,
      [userId]
    );

    const runningActivation = await getOne<ActivationRow>(
      `
        SELECT
          ata.id,
          ata.tier_id,
          vt.name AS tier_name,
          ata.asset,
          ata.strategy,
          ata.market_summary,
          ata.thesis,
          ata.status,
          ata.duration_minutes,
          ata.daily_slot_number,
          ata.started_at,
          ata.ends_at,
          ata.completed_at,
          ata.reservation_amount::float8 AS reservation_amount,
          ata.entry_price::float8 AS entry_price,
          ata.exit_price::float8 AS exit_price,
          ata.profit::float8 AS profit,
          vt.activation_limit_per_day AS daily_limit
        FROM ai_trading_activations ata
        JOIN vip_tiers vt ON vt.id = ata.tier_id
        WHERE ata.user_id = $1 AND ata.status = 'running'
        ORDER BY ata.started_at DESC
        LIMIT 1
      `,
      [userId]
    );

    const history = await dbQuery<ActivationRow>(
      `
        SELECT
          ata.id,
          ata.tier_id,
          vt.name AS tier_name,
          ata.asset,
          ata.strategy,
          ata.market_summary,
          ata.thesis,
          ata.status,
          ata.duration_minutes,
          ata.daily_slot_number,
          ata.started_at,
          ata.ends_at,
          ata.completed_at,
          ata.reservation_amount::float8 AS reservation_amount,
          ata.entry_price::float8 AS entry_price,
          ata.exit_price::float8 AS exit_price,
          ata.profit::float8 AS profit,
          vt.activation_limit_per_day AS daily_limit
        FROM ai_trading_activations ata
        JOIN vip_tiers vt ON vt.id = ata.tier_id
        WHERE ata.user_id = $1
        ORDER BY ata.started_at DESC
        LIMIT 8
      `,
      [userId]
    );

    return {
      currentTier: this.mapTierRow(tier),
      activeInvestment: tier.active_investment,
      runningActivation: runningActivation ? this.mapActivation(runningActivation) : null,
      remainingActivationsToday: Math.max(tier.activation_limit_per_day - (activationCount?.count ?? 0), 0),
      usedActivationsToday: activationCount?.count ?? 0,
      history: history.rows.map((activation) => this.mapActivation(activation))
    };
  }

  async startManualActivation(userId: string, reservationAmount?: number) {
    await this.finalizeDueActivations(userId);
    const tier = await this.getTierForUser(userId);

    if (tier.active_investment <= 0) {
      throw new BadRequestException("Activate a VIP tier with an approved deposit before starting AI trading.");
    }

    const runningActivation = await getOne<{ id: string }>(
      `
        SELECT id
        FROM ai_trading_activations
        WHERE user_id = $1 AND status = 'running'
        LIMIT 1
      `,
      [userId]
    );

    if (runningActivation) {
      throw new BadRequestException("An AI activation is already running. Wait for the current 2-minute cycle to finish.");
    }

    const activationCount = await getOne<{ count: number }>(
      `
        SELECT COUNT(*)::int AS count
        FROM ai_trading_activations
        WHERE user_id = $1
          AND started_at::date = CURRENT_DATE
      `,
      [userId]
    );

    const usedActivations = activationCount?.count ?? 0;
    if (usedActivations >= tier.activation_limit_per_day) {
      throw new BadRequestException(`Daily activation limit reached for ${tier.name}.`);
    }

    const effectiveReservationAmount = Number((reservationAmount ?? tier.active_investment).toFixed(2));
    if (!Number.isFinite(effectiveReservationAmount) || effectiveReservationAmount <= 0) {
      throw new BadRequestException("Enter a reservation amount greater than zero.");
    }

    if (effectiveReservationAmount > tier.active_investment) {
      throw new BadRequestException("Reservation amount exceeds available strategy funds.");
    }

    const reservationRules = await getOne<ReservationRulesRow>(
      `
        SELECT
          COALESCE((SELECT (value #>> '{}')::int FROM admin_settings WHERE key = 'platform.reservationFailuresPerDay'), 0) AS reservation_failures_per_day,
          (
            SELECT COUNT(*)::int
            FROM ai_trading_activations
            WHERE user_id = $1
              AND status = 'failed'
              AND started_at::date = CURRENT_DATE
          ) AS failed_reservations_today
      `,
      [userId]
    );

    const plan = this.buildActivationPlan(tier);
    const expectedIncome = this.buildExpectedIncome(effectiveReservationAmount, {
      dailyRoiMin: tier.daily_roi_min,
      dailyRoiMax: tier.daily_roi_max,
      activationLimitPerDay: tier.activation_limit_per_day
    });

    if ((reservationRules?.failed_reservations_today ?? 0) < (reservationRules?.reservation_failures_per_day ?? 0)) {
      const failedActivation = await getOne<ActivationRow>(
        `
          INSERT INTO ai_trading_activations (
            id,
            user_id,
            tier_id,
            asset,
            strategy,
            market_summary,
            thesis,
            status,
            duration_minutes,
            daily_slot_number,
            started_at,
            ends_at,
            completed_at,
            reservation_amount,
            profit
          )
          VALUES (
            gen_random_uuid(),
            $1,
            $2,
            $3,
            $4,
            $5,
            $6,
            'failed',
            $7,
            $8,
            NOW(),
            NOW(),
            NOW(),
            $9,
            0
          )
          RETURNING
            id,
            tier_id,
            $10::text AS tier_name,
            asset,
            strategy,
            market_summary,
            thesis,
            status,
            duration_minutes,
            daily_slot_number,
            started_at,
            ends_at,
            completed_at,
            reservation_amount::float8 AS reservation_amount,
            entry_price::float8 AS entry_price,
            exit_price::float8 AS exit_price,
            profit::float8 AS profit,
            $11::int AS daily_limit
        `,
        [
          userId,
          tier.id,
          plan.asset,
          plan.strategy,
          "Unable to participate, please contact your account manager.",
          "This reservation attempt was marked as failed by the current platform risk controls.",
          tier.activation_duration_minutes,
          usedActivations + 1,
          effectiveReservationAmount,
          tier.name,
          tier.activation_limit_per_day
        ]
      );

      return {
        outcome: "failed" as const,
        message: "Reservation failed. Please contact your account manager or try again tomorrow.",
        activation: this.mapActivation(failedActivation!),
        expectedIncomeMin: expectedIncome.min,
        expectedIncomeMax: expectedIncome.max,
        remainingActivationsToday: Math.max(tier.activation_limit_per_day - (usedActivations + 1), 0)
      };
    }

    const inserted = await getOne<ActivationRow>(
      `
        INSERT INTO ai_trading_activations (
          id,
          user_id,
          tier_id,
          asset,
          strategy,
          market_summary,
          thesis,
          status,
          duration_minutes,
          daily_slot_number,
          started_at,
          ends_at,
          reservation_amount
        )
        VALUES (
          gen_random_uuid(),
          $1,
          $2,
          $3,
          $4,
          $5,
          $6,
          'running',
          $7,
          $8,
          NOW(),
          NOW() + make_interval(mins => $7),
          $9
        )
        RETURNING
          id,
          tier_id,
          $10::text AS tier_name,
          asset,
          strategy,
          market_summary,
          thesis,
          status,
          duration_minutes,
          daily_slot_number,
          started_at,
          ends_at,
          completed_at,
          reservation_amount::float8 AS reservation_amount,
          entry_price::float8 AS entry_price,
          exit_price::float8 AS exit_price,
          profit::float8 AS profit,
          $11::int AS daily_limit
      `,
      [
        userId,
        tier.id,
        plan.asset,
        plan.strategy,
        plan.marketSummary,
        plan.thesis,
        tier.activation_duration_minutes,
        usedActivations + 1,
        effectiveReservationAmount,
        tier.name,
        tier.activation_limit_per_day
      ]
    );

    return {
      outcome: "running" as const,
      message: `AI trading started. This ${tier.activation_duration_minutes}-minute cycle is now analyzing ${plan.asset}.`,
      activation: this.mapActivation(inserted!),
      expectedIncomeMin: expectedIncome.min,
      expectedIncomeMax: expectedIncome.max,
      remainingActivationsToday: Math.max(tier.activation_limit_per_day - (usedActivations + 1), 0)
    };
  }

  async runProfitDistribution(scope: string) {
    const candidates = await this.getDistributionCandidates(scope);
    const distributed: ProfitDistributionEvent[] = [];

    for (const candidate of candidates) {
      const event = this.buildDistributionEvent(candidate);

      await withTransaction(async (client: PoolClient) => {
        await this.insertTradeLog(client, event);
      });

      await publishEvent("profit.distributed", event);
      distributed.push(event);
    }

    return {
      scope,
      processedUsers: distributed.length,
      totalProfit: Number(distributed.reduce((sum, event) => sum + event.profit, 0).toFixed(2)),
      events: distributed
    };
  }

  private async finalizeDueActivations(userId?: string) {
    const dueActivations = await dbQuery<{
      id: string;
      user_id: string;
      tier_id: number;
      asset: AssetType;
      strategy: string;
      duration_minutes: number;
      active_investment: number;
      reservation_amount: number;
      daily_roi_min: number;
      daily_roi_max: number;
      activation_limit_per_day: number;
    }>(
      `
        WITH latest_tier AS (
          SELECT DISTINCT ON (uv.user_id)
            uv.user_id,
            uv.tier_id
          FROM user_vip uv
          ORDER BY uv.user_id, uv.assigned_at DESC
        ),
        active_positions AS (
          SELECT
            user_id,
            COALESCE(SUM(balance), 0)::float8 AS active_investment
          FROM wallets
          GROUP BY user_id
        )
        SELECT
          ata.id,
          ata.user_id,
          ata.tier_id,
          ata.asset,
          ata.strategy,
          ata.duration_minutes,
          ap.active_investment,
          ata.reservation_amount::float8 AS reservation_amount,
          vt.daily_roi_min::float8 AS daily_roi_min,
          vt.daily_roi_max::float8 AS daily_roi_max,
          vt.activation_limit_per_day
        FROM ai_trading_activations ata
        JOIN latest_tier lt ON lt.user_id = ata.user_id
        JOIN vip_tiers vt ON vt.id = lt.tier_id
        JOIN active_positions ap ON ap.user_id = ata.user_id
        WHERE ata.status = 'running'
          AND ata.ends_at <= NOW()
          AND ($1::uuid IS NULL OR ata.user_id = $1::uuid)
      `,
      [userId ?? null]
    );

    for (const activation of dueActivations.rows) {
      const completion = this.buildActivationCompletion(activation);
      const updated = await withTransaction(async (client: PoolClient) => {
        const transition = await client.query<{ id: string }>(
          `
            UPDATE ai_trading_activations
            SET
              status = 'completed',
              completed_at = NOW(),
              entry_price = $2,
              exit_price = $3,
              profit = $4
            WHERE id = $1 AND status = 'running'
            RETURNING id
          `,
          [activation.id, completion.entryPrice, completion.exitPrice, completion.profit]
        );

        if (!transition.rowCount) {
          return null;
        }

        await this.insertTradeLog(client, {
          userId: activation.user_id,
          tierId: activation.tier_id,
          activationId: activation.id,
          asset: activation.asset,
          strategy: activation.strategy,
          profit: completion.profit,
          entryPrice: completion.entryPrice,
          exitPrice: completion.exitPrice,
          executedAt: new Date().toISOString()
        });

        return transition.rows[0];
      });

      if (!updated) {
        continue;
      }

      await publishEvent("profit.distributed", {
        userId: activation.user_id,
        tierId: activation.tier_id,
        activationId: activation.id,
        asset: activation.asset,
        strategy: activation.strategy,
        profit: completion.profit,
        entryPrice: completion.entryPrice,
        exitPrice: completion.exitPrice,
        executedAt: new Date().toISOString()
      });
    }
  }

  private async getDistributionCandidates(scope: string) {
    const result = await dbQuery<DistributionCandidate>(
      `
        WITH active_positions AS (
          SELECT
            w.user_id,
            COALESCE(SUM(w.balance), 0)::float8 AS active_investment
          FROM wallets w
          GROUP BY w.user_id
        ),
        latest_tier AS (
          SELECT DISTINCT ON (uv.user_id)
            uv.user_id,
            uv.tier_id
          FROM user_vip uv
          ORDER BY uv.user_id, uv.assigned_at DESC
        )
        SELECT
          ap.user_id,
          COALESCE(lt.tier_id, 1) AS tier_id,
          vt.daily_roi_min::float8 AS daily_roi_min,
          vt.daily_roi_max::float8 AS daily_roi_max,
          ap.active_investment::float8 AS active_investment
        FROM active_positions ap
        LEFT JOIN latest_tier lt ON lt.user_id = ap.user_id
        JOIN vip_tiers vt ON vt.id = COALESCE(lt.tier_id, 1)
        WHERE ap.active_investment > 0
          AND ($1 = 'all' OR ap.user_id = $1)
      `,
      [scope]
    );

    return result.rows;
  }

  private buildDistributionEvent(candidate: DistributionCandidate): ProfitDistributionEvent {
    const sampledRoi = this.sampleRoi(candidate.daily_roi_min, candidate.daily_roi_max);
    const profit = calculateDailyProfit(candidate.active_investment, sampledRoi);
    const entryPrice = Number((5000 + Math.random() * 600).toFixed(2));
    const exitPrice = Number((entryPrice + profit / 4).toFixed(2));

    return {
      userId: candidate.user_id,
      tierId: candidate.tier_id,
      profit,
      asset: "USD",
      strategy: this.pickStrategy(candidate.tier_id),
      entryPrice,
      exitPrice,
      executedAt: new Date().toISOString()
    };
  }

  private async getTierForUser(userId: string) {
    const tier = await getOne<ActivationTierRow>(
      `
        WITH latest_tier AS (
          SELECT DISTINCT ON (uv.user_id)
            uv.user_id,
            uv.tier_id
          FROM user_vip uv
          WHERE uv.user_id = $1
          ORDER BY uv.user_id, uv.assigned_at DESC
        ),
        active_positions AS (
          SELECT COALESCE(SUM(balance), 0)::float8 AS active_investment
          FROM wallets
          WHERE user_id = $1
        ),
        computed_tier AS (
          SELECT id
          FROM vip_tiers
          WHERE min_deposit <= (SELECT active_investment FROM active_positions)
          ORDER BY min_deposit DESC
          LIMIT 1
        )
        SELECT
          vt.id,
          vt.name,
          vt.min_deposit::float8 AS min_deposit,
          vt.daily_roi_min::float8 AS daily_roi_min,
          vt.daily_roi_max::float8 AS daily_roi_max,
          vt.activation_limit_per_day,
          vt.activation_duration_minutes,
          vt.activation_assets,
          ap.active_investment
        FROM active_positions ap
        LEFT JOIN latest_tier lt ON TRUE
        LEFT JOIN computed_tier ct ON TRUE
        JOIN vip_tiers vt ON vt.id = COALESCE(lt.tier_id, ct.id, 1)
      `,
      [userId]
    );

    if (tier) {
      return tier;
    }

    const starter = getTierConfig(1);
    return {
      id: starter.id,
      name: starter.name,
      min_deposit: starter.minDeposit,
      daily_roi_min: starter.dailyRoiMin,
      daily_roi_max: starter.dailyRoiMax,
      activation_limit_per_day: starter.activationLimitPerDay,
      activation_duration_minutes: starter.activationDurationMinutes,
      activation_assets: starter.activationAssets,
      active_investment: 0
    };
  }

  private buildActivationPlan(tier: ActivationTierRow) {
    const plans: Record<number, Array<{ asset: AssetType; strategy: string; marketSummary: string; thesis: string }>> = {
      1: [
        {
          asset: "BTC",
          strategy: "Starter Momentum Pulse",
          marketSummary: "BTC is holding above intraday VWAP with steady spot volume and low liquidation pressure.",
          thesis: "The engine is scanning for a short continuation burst and tightening exposure if momentum stalls."
        },
        {
          asset: "USD",
          strategy: "Stable Yield Core",
          marketSummary: "Dollar liquidity is stable and volatility is compressed, which suits the defensive core model.",
          thesis: "This run targets controlled carry-style profit with a lower risk profile for Starter accounts."
        }
      ],
      2: [
        {
          asset: "ETH",
          strategy: "Silver Trend Relay",
          marketSummary: "ETH order flow is positive and correlation with BTC remains supportive for short trend trades.",
          thesis: "The model is timing a quick follow-through trade while limiting downside with tighter exits."
        }
      ],
      3: [
        {
          asset: "EUR",
          strategy: "Gold FX Rotation",
          marketSummary: "EUR liquidity is clean and short-term macro dispersion is opening brief mean-reversion windows.",
          thesis: "The engine is looking for a two-minute FX rotation entry with disciplined profit capture."
        }
      ],
      4: [
        {
          asset: "STOCKS",
          strategy: "Platinum Index Burst",
          marketSummary: "Index breadth is improving and sector rotation favors fast US session momentum entries.",
          thesis: "The run is positioning into a short-duration index basket move with higher conviction than the base tiers."
        },
        {
          asset: "BTC",
          strategy: "Platinum Crypto Impulse",
          marketSummary: "BTC derivatives funding is neutral while spot bids are absorbing pullbacks, a healthy setup for a timed burst.",
          thesis: "This activation hunts a quick breakout window and closes automatically after the 2-minute cycle."
        }
      ],
      5: [
        {
          asset: "USDT_ERC20",
          strategy: "Diamond Cross-Market Arbitrage",
          marketSummary: "Cross-venue spreads remain tradeable and the premium engine can allocate capital across multiple internal books.",
          thesis: "Diamond mode is using the broadest universe and highest click allowance to harvest short-lived inefficiencies."
        }
      ]
    };

    const options = plans[tier.id] ?? plans[1];
    return options[Math.floor(Math.random() * options.length)];
  }

  private buildActivationCompletion(activation: {
    active_investment: number;
    reservation_amount: number;
    daily_roi_min: number;
    daily_roi_max: number;
    activation_limit_per_day: number;
  }) {
    const reservedAmount = activation.reservation_amount > 0 ? activation.reservation_amount : activation.active_investment;
    const sampledRoi = this.sampleRoi(activation.daily_roi_min, activation.daily_roi_max);
    const fullDayProfit = calculateDailyProfit(reservedAmount, sampledRoi);
    const profit = Number((fullDayProfit / Math.max(activation.activation_limit_per_day, 1)).toFixed(2));
    const entryPrice = Number((5000 + Math.random() * 700).toFixed(2));
    const exitPrice = Number((entryPrice + Math.max(profit / 6, 1.2)).toFixed(2));
    return { profit, entryPrice, exitPrice };
  }

  private buildExpectedIncome(
    reservationAmount: number,
    tier: { dailyRoiMin: number; dailyRoiMax: number; activationLimitPerDay: number }
  ) {
    const fullDayMinProfit = calculateDailyProfit(reservationAmount, tier.dailyRoiMin);
    const fullDayMaxProfit = calculateDailyProfit(reservationAmount, tier.dailyRoiMax);

    return {
      min: Number((fullDayMinProfit / Math.max(tier.activationLimitPerDay, 1)).toFixed(2)),
      max: Number((fullDayMaxProfit / Math.max(tier.activationLimitPerDay, 1)).toFixed(2))
    };
  }

  private mapTierRow(tier: ActivationTierRow): VipTier {
    return {
      id: tier.id,
      name: tier.name,
      minDeposit: tier.min_deposit,
      dailyRoiMin: tier.daily_roi_min,
      dailyRoiMax: tier.daily_roi_max,
      dailyRoi: tier.daily_roi_max,
      monthlyRoi: Number((tier.daily_roi_max * 30).toFixed(2)),
      activationLimitPerDay: tier.activation_limit_per_day,
      activationDurationMinutes: tier.activation_duration_minutes,
      activationAssets: tier.activation_assets,
      features: getTierConfig(tier.id).features
    };
  }

  private mapActivation(activation: ActivationRow): AiTradingActivation {
    return {
      id: activation.id,
      tierId: activation.tier_id,
      tierName: activation.tier_name,
      asset: activation.asset,
      strategy: activation.strategy,
      marketSummary: activation.market_summary,
      thesis: activation.thesis,
      status: activation.status,
      startedAt: activation.started_at,
      endsAt: activation.ends_at,
      completedAt: activation.completed_at,
      durationMinutes: activation.duration_minutes,
      dailySlotNumber: activation.daily_slot_number,
      dailyLimit: activation.daily_limit,
      reservationAmount: activation.reservation_amount,
      entryPrice: activation.entry_price,
      exitPrice: activation.exit_price,
      profit: activation.profit,
      expectedIncomeMin: activation.reservation_amount
        ? this.buildExpectedIncome(activation.reservation_amount, getTierConfig(activation.tier_id)).min
        : null,
      expectedIncomeMax: activation.reservation_amount
        ? this.buildExpectedIncome(activation.reservation_amount, getTierConfig(activation.tier_id)).max
        : null
    };
  }

  private sampleRoi(min: number, max: number) {
    if (max <= min) {
      return min;
    }

    return Number((min + Math.random() * (max - min)).toFixed(6));
  }

  private async insertTradeLog(client: PoolClient, event: ProfitDistributionEvent) {
    await client.query(
      `
        INSERT INTO trade_logs (
          id,
          user_id,
          asset,
          strategy,
          entry_price,
          exit_price,
          profit,
          executed_at
        )
        VALUES (
          gen_random_uuid(),
          $1,
          $2,
          $3,
          $4,
          $5,
          $6,
          $7
        )
      `,
      [event.userId, event.asset, event.strategy, event.entryPrice, event.exitPrice, event.profit, event.executedAt]
    );
  }

  private pickStrategy(tierId: number) {
    const strategies: Record<number, string> = {
      1: "Stable Yield Core",
      2: "Forex Mean Reversion",
      3: "Cross-Asset Momentum",
      4: "US Index Rotation",
      5: "Custom Quant Basket"
    };

    return strategies[tierId] ?? "Stable Yield Core";
  }
}
