import { useMemo, useState } from "react";
import axios from "axios";
import toast from "react-hot-toast";
import { Check, CheckCircle2, ChevronDown, Copy, Landmark, X } from "lucide-react";
import { useEffect } from "react";
import type { AssetType, DepositAddressMap } from "@nevo/shared-types";
import { SUPPORTED_ASSETS, formatCurrency } from "@nevo/shared-utils";
import { MobilePageHeader } from "@/components/mobile-page-header";

const walletApi = axios.create({
  baseURL: import.meta.env.VITE_WALLET_API_URL ?? "http://localhost:4002/api"
});

const assetLabels: Record<AssetType, string> = {
  BTC: "BTC",
  ETH: "ETH",
  USDT_TRC20: "USDT (TRC20)",
  USDT_ERC20: "USDT (ERC20)",
  USD: "USD",
  EUR: "EUR",
  GBP: "GBP",
  STOCKS: "STOCKS"
};

type DepositResponse = {
  id: string;
  type: "deposit";
  asset: AssetType;
  amount: number;
  status: "pending";
  walletAddress: string;
  message: string;
};

export function DepositPage() {
  const [asset, setAsset] = useState<AssetType>("USDT_TRC20");
  const [amount, setAmount] = useState("100");
  const [submitting, setSubmitting] = useState(false);
  const [depositResponse, setDepositResponse] = useState<DepositResponse | null>(null);
  const [assetPickerOpen, setAssetPickerOpen] = useState(false);
  const [depositAddresses, setDepositAddresses] = useState<DepositAddressMap | null>(null);

  const parsedAmount = useMemo(() => Number(amount || 0), [amount]);
  const selectedWalletAddress = depositResponse?.walletAddress ?? depositAddresses?.[asset] ?? "";

  useEffect(() => {
    const token = localStorage.getItem("nevo.accessToken");
    if (!token) {
      return;
    }

    let active = true;

    const loadDepositAddresses = async () => {
      try {
        const response = await walletApi.get<DepositAddressMap>("/wallet/deposit-addresses", {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });

        if (active) {
          setDepositAddresses(response.data);
        }
      } catch {
        if (active) {
          setDepositAddresses(null);
        }
      }
    };

    void loadDepositAddresses();

    return () => {
      active = false;
    };
  }, []);

  const submitDeposit = async () => {
    const token = localStorage.getItem("nevo.accessToken");
    if (!token) {
      toast.error("Sign in first.");
      return;
    }

    if (!parsedAmount || parsedAmount < 1) {
      toast.error("Enter a deposit amount of at least 1.");
      return;
    }

    setSubmitting(true);
    try {
      const response = await walletApi.post<DepositResponse>(
        "/wallet/deposits",
        {
          asset,
          amount: parsedAmount
        },
        {
        headers: {
          Authorization: `Bearer ${token}`
        }
        }
      );

      setDepositResponse(response.data);
      toast.success(response.data.message);
    } catch (error) {
      if (axios.isAxiosError(error)) {
        const responseMessage = error.response?.data?.message;
        if (typeof responseMessage === "string") {
          toast.error(responseMessage);
        } else {
          toast.error("Could not submit deposit.");
        }
      } else {
        toast.error("Could not submit deposit.");
      }
    } finally {
      setSubmitting(false);
    }
  };

  const copyWalletAddress = async () => {
    if (!selectedWalletAddress) {
      return;
    }

    await navigator.clipboard.writeText(selectedWalletAddress);
    toast.success("Wallet address copied.");
  };

  return (
    <div className="pb-6">
      <MobilePageHeader title="Deposit" subtitle="fund your account" />

      {assetPickerOpen ? (
        <div className="fixed inset-0 z-40 bg-[#020223]/75 backdrop-blur-sm">
          <button
            aria-label="Close asset picker"
            className="absolute inset-0"
            onClick={() => setAssetPickerOpen(false)}
            type="button"
          />
          <div className="absolute inset-x-4 bottom-6 rounded-[30px] border border-cyan-300/15 bg-[linear-gradient(180deg,rgba(14,19,142,0.98)_0%,rgba(9,11,110,0.99)_45%,rgba(6,8,82,1)_100%)] p-5 shadow-[0_28px_60px_rgba(0,0,0,0.4)]">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="text-[1.35rem] font-extrabold text-white">Choose asset</div>
                <div className="mt-1 text-sm text-slate-300">Select the destination funding network.</div>
              </div>
              <button
                className="flex h-11 w-11 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white"
                onClick={() => setAssetPickerOpen(false)}
                type="button"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-5 space-y-3">
              {SUPPORTED_ASSETS.map((supportedAsset) => (
                <button
                  key={supportedAsset}
                  className={`flex w-full items-center justify-between rounded-[22px] border px-4 py-4 text-left transition ${
                    asset === supportedAsset
                      ? "border-cyan-300/30 bg-cyan-300/10 text-cyan-100"
                      : "border-white/10 bg-white/5 text-white"
                  }`}
                  onClick={() => {
                    setAsset(supportedAsset);
                    setAssetPickerOpen(false);
                  }}
                  type="button"
                >
                  <span className="text-[15px] font-semibold">{assetLabels[supportedAsset]}</span>
                  {asset === supportedAsset ? <Check className="h-5 w-5" /> : null}
                </button>
              ))}
            </div>
          </div>
        </div>
      ) : null}

      <div className="px-4 pt-5">
        <section className="neon-panel p-5">
          <div className="flex items-start gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-cyan-300/10 text-cyan-200">
              <Landmark className="h-5 w-5" />
            </div>
            <div>
              <div className="text-[1.15rem] font-bold text-white">Create a deposit request</div>
              <div className="mt-1 text-[13px] leading-5 text-slate-300">
                Choose the asset and amount. The destination wallet address will be returned after submission.
              </div>
            </div>
          </div>
        </section>

        <section className="neon-soft-panel mt-5 grid gap-4 p-5">
          <label className="grid gap-2">
            <span className="text-sm text-slate-300">Asset</span>
            <button
              className="flex items-center justify-between rounded-[20px] border border-white/10 bg-[#080b56]/90 px-4 py-4 text-left text-[15px] text-white outline-none"
              onClick={() => setAssetPickerOpen(true)}
              type="button"
            >
              <span>{assetLabels[asset]}</span>
              <ChevronDown className="h-5 w-5 text-white/70" />
            </button>
          </label>

          <label className="grid gap-2">
            <span className="text-sm text-slate-300">Amount</span>
            <input
              className="rounded-[20px] border border-white/10 bg-[#080b56]/90 px-4 py-4 text-[15px] text-white outline-none"
              inputMode="decimal"
              min="1"
              step="0.01"
              type="number"
              value={amount}
              onChange={(event) => setAmount(event.target.value)}
            />
          </label>

          <div className="rounded-[20px] border border-cyan-300/20 bg-cyan-300/10 px-4 py-4 text-[13px] leading-5 text-cyan-100">
            Request total: {formatCurrency(parsedAmount || 0)}. The destination wallet address will be returned after submission.
          </div>

          {selectedWalletAddress ? (
            <div className="rounded-[20px] border border-white/10 bg-white/5 p-4">
              <div className="text-sm text-slate-400">Funding address</div>
              <div className="mt-2 break-all text-[15px] font-semibold text-white">{selectedWalletAddress}</div>
              <button
                className="mt-4 inline-flex items-center gap-2 rounded-full border border-cyan-300/25 bg-cyan-300/10 px-4 py-2 text-sm font-semibold text-cyan-100"
                onClick={() => void copyWalletAddress()}
                type="button"
              >
                <Copy className="h-4 w-4" />
                Copy address
              </button>
            </div>
          ) : null}

          <button
            className="rounded-[20px] bg-cyan-400 px-4 py-4 text-[15px] font-semibold text-slate-950 disabled:opacity-60"
            disabled={submitting}
            onClick={submitDeposit}
            type="button"
          >
            {submitting ? "Submitting..." : "Submit deposit"}
          </button>
        </section>

        {depositResponse ? (
          <section className="neon-panel mt-5 p-5">
            <div className="flex items-center gap-2 text-cyan-200">
              <CheckCircle2 className="h-4 w-4" />
              <span className="text-sm uppercase tracking-[0.22em]">Deposit request created</span>
            </div>

            <div className="mt-4 rounded-[22px] border border-white/10 bg-white/5 p-4">
              <div className="text-sm text-slate-400">Wallet address</div>
              <div className="mt-2 break-all text-[15px] font-semibold text-white">{selectedWalletAddress}</div>
              <button
                className="mt-4 inline-flex items-center gap-2 rounded-full border border-cyan-300/25 bg-cyan-300/10 px-4 py-2 text-sm font-semibold text-cyan-100"
                onClick={() => void copyWalletAddress()}
                type="button"
              >
                <Copy className="h-4 w-4" />
                Copy address
              </button>
            </div>

            <div className="mt-4 rounded-[22px] border border-white/10 bg-white/5 p-4 text-[13px] leading-6 text-slate-300">
              <div>Transaction ID: <span className="font-medium text-white">{depositResponse.id}</span></div>
              <div className="mt-1">Status: <span className="font-medium uppercase text-cyan-100">{depositResponse.status}</span></div>
              <div className="mt-1">{depositResponse.message}</div>
            </div>
          </section>
        ) : null}
      </div>
    </div>
  );
}
